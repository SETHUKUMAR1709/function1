def function_2():
    print("This is function - 2")
    return 1


from setuptools import find_packages, setup

setup(
    name="firstlib12345",
    version="0.0.17",
    description="simple lib",
    packages=['src'],
    url="https://github.com/SETHUKUMAR1709/integrated/tree/main/firstlib12345",
    author="GGEZ",
    author_email="sethukumars774@gmail.com",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    install_requires=[],
    extras_require={},
    python_requires=">=3.11",
)
import function1
import function2
def function1():
    print("This is function - 1")
    return 1
